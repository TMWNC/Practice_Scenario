﻿namespace CSV_KPI
{
    partial class frmRetrieve
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbDisplay = new System.Windows.Forms.ListBox();
            this.btnRetrieveLB = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pbComp = new System.Windows.Forms.ProgressBar();
            this.lblCompout = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.cbChoice = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblNameout = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbDisplay
            // 
            this.lbDisplay.FormattingEnabled = true;
            this.lbDisplay.Location = new System.Drawing.Point(23, 22);
            this.lbDisplay.Name = "lbDisplay";
            this.lbDisplay.Size = new System.Drawing.Size(188, 108);
            this.lbDisplay.TabIndex = 0;
            // 
            // btnRetrieveLB
            // 
            this.btnRetrieveLB.Location = new System.Drawing.Point(78, 136);
            this.btnRetrieveLB.Name = "btnRetrieveLB";
            this.btnRetrieveLB.Size = new System.Drawing.Size(75, 23);
            this.btnRetrieveLB.TabIndex = 1;
            this.btnRetrieveLB.Text = "Retrieve";
            this.btnRetrieveLB.UseVisualStyleBackColor = true;
            this.btnRetrieveLB.Click += new System.EventHandler(this.btnRetrieveLB_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(560, 106);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Completion (%)";
            // 
            // pbComp
            // 
            this.pbComp.Location = new System.Drawing.Point(563, 136);
            this.pbComp.Name = "pbComp";
            this.pbComp.Size = new System.Drawing.Size(103, 23);
            this.pbComp.TabIndex = 3;
            // 
            // lblCompout
            // 
            this.lblCompout.AutoSize = true;
            this.lblCompout.Location = new System.Drawing.Point(653, 106);
            this.lblCompout.Name = "lblCompout";
            this.lblCompout.Size = new System.Drawing.Size(13, 13);
            this.lblCompout.TabIndex = 4;
            this.lblCompout.Text = "0";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(485, 36);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 5;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // cbChoice
            // 
            this.cbChoice.FormattingEnabled = true;
            this.cbChoice.Location = new System.Drawing.Point(358, 38);
            this.cbChoice.Name = "cbChoice";
            this.cbChoice.Size = new System.Drawing.Size(121, 21);
            this.cbChoice.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(358, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Name";
            // 
            // lblNameout
            // 
            this.lblNameout.AutoSize = true;
            this.lblNameout.Location = new System.Drawing.Point(361, 136);
            this.lblNameout.Name = "lblNameout";
            this.lblNameout.Size = new System.Drawing.Size(22, 13);
            this.lblNameout.TabIndex = 8;
            this.lblNameout.Text = ".....";
            // 
            // frmRetrieve
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblNameout);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbChoice);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.lblCompout);
            this.Controls.Add(this.pbComp);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnRetrieveLB);
            this.Controls.Add(this.lbDisplay);
            this.Name = "frmRetrieve";
            this.Text = "frmRetrieve";
            this.Load += new System.EventHandler(this.frmRetrieve_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbDisplay;
        private System.Windows.Forms.Button btnRetrieveLB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ProgressBar pbComp;
        private System.Windows.Forms.Label lblCompout;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ComboBox cbChoice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblNameout;
    }
}